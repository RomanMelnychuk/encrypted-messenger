import chats from './chats/chats.slice';
import sidebar from './sidebar/sidebar.slice';
import user from './user/user.slice';

export default {
	chats,
	user,
	sidebar,
};
