namespace Messenger.Domain.Enums;

public enum TypeEncryption
{
    RSA_AES = 0,
    Camellia_AES = 1,
    Browfish_AES = 2,
}