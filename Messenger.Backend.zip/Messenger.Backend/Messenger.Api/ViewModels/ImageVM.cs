namespace Messenger.Backend.ViewModels;

public record ImageViewModel(string Image);