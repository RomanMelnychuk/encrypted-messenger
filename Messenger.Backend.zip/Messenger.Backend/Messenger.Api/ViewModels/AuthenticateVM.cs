namespace Messenger.Backend.ViewModels;

public record AuthenticateViewModel(string Email, string Password);