namespace Messenger.Backend.ViewModels;

public record UpdateUserViewModel(string Email, string FullName, string UserName, string Description);