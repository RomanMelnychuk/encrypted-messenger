namespace Messenger.Backend.ViewModels;

public record ErrorResponseModel(string Message);