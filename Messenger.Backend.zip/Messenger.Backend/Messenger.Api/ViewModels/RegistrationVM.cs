namespace Messenger.Backend.ViewModels;

public record RegistrationViewModel(string Email, string Password, string UserName);
