namespace Messenger.Backend.ViewModels;

public record GoogleAuthViewModel(string Email, string Picture, string FullName);