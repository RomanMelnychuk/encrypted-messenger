namespace Messenger.Application.Exceptions;

public class ChatIsExistException : Exception
{
}